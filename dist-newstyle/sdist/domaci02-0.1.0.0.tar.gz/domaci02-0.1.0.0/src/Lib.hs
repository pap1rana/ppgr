module Lib
    ( someFunc
    ) where

import Dom1
import Data.Matrix

someFunc :: IO ()
someFunc = print (MkTacka 1 2 3)