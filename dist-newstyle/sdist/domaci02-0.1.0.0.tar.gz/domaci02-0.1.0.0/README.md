# Primena Projektivne Geometrije u Racunarstvu

sudo apt-get install stack

compiled:    stack run

interpreted: stack ghci
